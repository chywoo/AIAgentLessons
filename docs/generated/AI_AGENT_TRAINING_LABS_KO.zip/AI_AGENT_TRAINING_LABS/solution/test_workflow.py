import pytest
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.types import Command
from workflow import Simulator, build_workflow, input_for, approval_for

CONFIG = {"configurable": {"thread_id": "test-42"}}

def start(fixture="normal"):
    sim = Simulator()
    graph = build_workflow(InMemorySaver(), sim)
    graph.invoke(input_for(fixture), CONFIG)
    return graph, sim, graph.get_state(CONFIG).values

def test_normal_waits_without_execution():
    graph, sim, state = start()
    assert state["status"] == "awaiting_approval"
    assert graph.get_state(CONFIG).next == ("approval",)
    assert len(sim.calls) == 0

def test_approve_runs_simulator_once():
    graph, sim, state = start()
    result = graph.invoke(Command(resume=approval_for(state["plan"], "approve")), CONFIG)
    assert result["status"] == "simulated"
    assert len(sim.calls) == 1

def test_reject_never_executes():
    graph, sim, state = start()
    result = graph.invoke(Command(resume=approval_for(state["plan"], "reject")), CONFIG)
    assert result["status"] == "rejected"
    assert len(sim.calls) == 0

@pytest.mark.parametrize("fixture", ["invented_source", "no_runbook"])
def test_missing_evidence_blocks(fixture):
    graph, sim, state = start(fixture)
    assert state["status"] == "blocked"
    assert not graph.get_state(CONFIG).next
    assert len(sim.calls) == 0
    assert "invented-9" not in state["verified_sources"]
    if fixture == "invented_source":
        assert state["rejected_sources"] == ["invented-9"]

@pytest.mark.parametrize("field,bad", [("incident_id", "OTHER"), ("action_id", "other-action"),
                                         ("service", "another-api"), ("plan_version", 99)])
def test_wrong_approval_target_never_executes(field, bad):
    graph, sim, state = start()
    decision = approval_for(state["plan"], "approve")
    decision[field] = bad
    result = graph.invoke(Command(resume=decision), CONFIG)
    assert result["reason"] == "approval_target_mismatch"
    assert len(sim.calls) == 0

@pytest.mark.parametrize("fixture,code", [("tool_timeout", "transient_timeout"),
                                           ("invalid_output", "invalid_output")])
def test_injected_failures_are_classified(fixture, code):
    _, sim, state = start(fixture)
    assert state["status"] == "blocked" and state["reason"] == code
    assert len(sim.calls) == 0

def test_sqlite_reopen_and_resume(tmp_path):
    db = str(tmp_path / "checkpoint.sqlite")
    sim = Simulator()
    with SqliteSaver.from_conn_string(db) as saver:
        graph = build_workflow(saver, sim)
        graph.invoke(input_for(), CONFIG)
    with SqliteSaver.from_conn_string(db) as saver:
        graph = build_workflow(saver, sim)
        assert graph.get_state(CONFIG).values["status"] == "awaiting_approval"
        state = graph.get_state(CONFIG).values
        result = graph.invoke(Command(resume=approval_for(state["plan"], "reject")), CONFIG)
        assert result["status"] == "rejected"
        assert len(sim.calls) == 0

def test_approval_missing_fields_never_executes():
    graph, sim, _ = start()
    result = graph.invoke(Command(resume={"decision": "approve"}), CONFIG)
    assert result["reason"] == "approval_target_mismatch"
    assert len(sim.calls) == 0
