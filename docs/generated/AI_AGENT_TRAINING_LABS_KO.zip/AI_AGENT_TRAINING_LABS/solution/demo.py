"""Run from this directory. State is stored locally; there is no network access."""
import argparse
import json
from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.types import Command
from workflow import Simulator, build_workflow, input_for, approval_for, FIXTURES

parser = argparse.ArgumentParser()
parser.add_argument("operation", choices=["start", "resume", "status"])
parser.add_argument("--db", default="training.sqlite")
parser.add_argument("--thread", default="training-42")
parser.add_argument("--fixture", default="normal", choices=sorted(FIXTURES))
parser.add_argument("--decision", default="reject", choices=["approve", "reject"])
args = parser.parse_args()
config = {"configurable": {"thread_id": args.thread}}
simulator = Simulator()
with SqliteSaver.from_conn_string(args.db) as saver:
    graph = build_workflow(saver, simulator)
    current = graph.get_state(config)
    if args.operation == "start":
        if current.values:
            parser.error("Thread already exists. Use status/resume or a new --thread.")
        graph.invoke(input_for(args.fixture), config)
    elif args.operation == "resume":
        if not current.values or not current.next:
            parser.error("No paused execution for this thread.")
        graph.invoke(Command(resume=approval_for(current.values["plan"], args.decision)), config)
    state = graph.get_state(config)
    print(json.dumps({"thread": args.thread, "state": state.values,
                      "pending_nodes": list(state.next),
                      "simulator_calls_this_process": len(simulator.calls)},
                     ensure_ascii=False, indent=2))
