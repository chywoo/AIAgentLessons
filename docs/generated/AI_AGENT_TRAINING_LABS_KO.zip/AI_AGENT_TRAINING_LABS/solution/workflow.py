"""Offline training model: synthetic evidence, policy gate, interrupt, simulator."""
from typing import Literal, TypedDict
from pydantic import BaseModel, Field, ValidationError
from langgraph.graph import StateGraph, START, END
from langgraph.types import interrupt

class Finding(BaseModel):
    service: str
    source_ids: list[str]
    summary: str = Field(min_length=1)

class IncidentState(TypedDict, total=False):
    incident_id: str
    service: str
    fixture: str
    metrics: dict
    runbook: dict
    observed_sources: list[str]
    verified_sources: list[str]
    rejected_sources: list[str]
    plan: dict
    status: str
    reason: str
    approval: dict
    execution: dict

class FakeAgent:
    def __init__(self, payload: dict):
        self.payload = payload
    def invoke(self, _request: dict) -> dict:
        return self.payload.copy()

class Simulator:
    """Counts local calls only. No email, DB change or network operation."""
    def __init__(self):
        self.calls: list[dict] = []
    def execute(self, plan: dict) -> dict:
        self.calls.append(plan.copy())
        return {"status": "simulated", "action_id": plan["action_id"]}

FIXTURES = {"normal", "invented_source", "no_runbook", "tool_timeout", "invalid_output"}

def input_for(fixture: str = "normal") -> IncidentState:
    if fixture not in FIXTURES:
        raise ValueError(f"Unknown fixture: {fixture}")
    return {"incident_id": "INC-042", "service": "checkout-api", "fixture": fixture,
            "plan": {"incident_id": "INC-042", "action_id": "restart-01",
                     "service": "checkout-api", "plan_version": 1}}

def approval_for(plan: dict, decision: Literal["approve", "reject"]) -> dict:
    return {**plan, "decision": decision}

def approval_matches(plan: dict, approval: dict) -> bool:
    keys = ("incident_id", "action_id", "service", "plan_version")
    return all(k in plan and k in approval and plan[k] == approval[k] for k in keys)

def build_workflow(checkpointer, simulator: Simulator):
    def metrics(state):
        if state["fixture"] == "tool_timeout":
            return {"metrics": {"status": "error", "error_code": "transient_timeout"}}
        raw = {"service": state["service"], "source_ids": ["metric-7"],
               "summary": "Synthetic: elevated latency and HTTP 503"}
        if state["fixture"] == "invalid_output":
            raw["source_ids"] = "not-a-list"
        try:
            result = Finding.model_validate(FakeAgent(raw).invoke(state))
        except ValidationError:
            return {"metrics": {"status": "error", "error_code": "invalid_output"}}
        return {"metrics": {"status": "ok", "finding": result.model_dump(),
                            "observed_ids": ["metric-7"], "tool_used": True}}

    def runbook(state):
        observed = [] if state["fixture"] == "no_runbook" else ["runbook-12"]
        claimed = ["invented-9"] if state["fixture"] == "invented_source" else observed
        result = FakeAgent({"service": state["service"], "source_ids": claimed,
                            "summary": "Synthetic restart guidance"}).invoke(state)
        return {"runbook": {"status": "ok", "finding": result,
                            "observed_ids": observed, "tool_used": True}}

    def gate(state):
        results = [state["metrics"], state["runbook"]]
        failed = next((r for r in results if r["status"] != "ok"), None)
        if failed:
            return {"status": "blocked", "reason": failed["error_code"],
                    "verified_sources": [], "rejected_sources": []}
        observed = set().union(*(set(r["observed_ids"]) for r in results))
        claimed = set().union(*(set(r["finding"]["source_ids"]) for r in results))
        rejected = claimed - observed
        valid = all(r["tool_used"] and r["observed_ids"] and
                    r["finding"]["source_ids"] and
                    r["finding"]["service"] == state["service"] for r in results)
        allowed = valid and not rejected
        return {"observed_sources": sorted(observed),
                "verified_sources": sorted(claimed & observed),
                "rejected_sources": sorted(rejected),
                "status": "awaiting_approval" if allowed else "blocked",
                "reason": "evidence_gate_pass" if allowed else "insufficient_evidence"}

    def approval(state):
        decision = interrupt({"kind": "approval_required", "plan": state["plan"]})
        if not isinstance(decision, dict) or not approval_matches(state["plan"], decision):
            return {"status": "blocked", "reason": "approval_target_mismatch"}
        if decision.get("decision") == "reject":
            return {"approval": decision, "status": "rejected", "reason": "human_rejected"}
        if decision.get("decision") != "approve":
            return {"status": "blocked", "reason": "invalid_decision"}
        return {"approval": decision, "status": "approved"}

    def execute(state):
        # Deliberately a simulator; authentication and external idempotency are not implemented.
        if state.get("status") != "approved" or not approval_matches(state["plan"], state.get("approval", {})):
            raise ValueError("execution_requires_matching_approval")
        return {"execution": simulator.execute(state["plan"]), "status": "simulated"}

    graph = StateGraph(IncidentState)
    for name, fn in (("metrics", metrics), ("runbook", runbook), ("gate", gate),
                     ("approval", approval), ("execute", execute)):
        graph.add_node(name, fn)
    graph.add_edge(START, "metrics")
    graph.add_edge(START, "runbook")
    graph.add_edge(["metrics", "runbook"], "gate")
    graph.add_conditional_edges("gate", lambda s: "approval" if s["status"] == "awaiting_approval" else END)
    graph.add_conditional_edges("approval", lambda s: "execute" if s["status"] == "approved" else END)
    graph.add_edge("execute", END)
    return graph.compile(checkpointer=checkpointer)
