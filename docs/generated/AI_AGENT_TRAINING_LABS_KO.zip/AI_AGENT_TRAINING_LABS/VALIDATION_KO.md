# 제작 검증 기록

기준일: 2026-10-20 (America/Toronto)

- Python 3.12.14 / Linux x86_64의 새 가상환경에 requirements.txt 설치.
- 다운로드 해시 검증을 유지한 설치 성공: `uv pip install --require-hashes -r requirements.txt`.
- `solution/`에서 `python -m pytest -q test_workflow.py`: **13 passed**.
- 별도 프로세스에서 `demo.py start` 후 같은 SQLite와 thread로 `demo.py resume --decision reject` 실행.
- 관측 결과: 시작 시 awaiting_approval, 재개 후 rejected, 현재 프로세스 Simulator 호출 0회.
- 테스트는 교육용 FakeAgent/Simulator와 실제 로컬 LangGraph·SQLite를 사용.
- 실제 모델 API, MCP Server, Qdrant, Email, 운영 DB 변경은 검증하지 않음.
- starter/policy.py의 TODO는 학습자 과제이며 위 13개 정답 테스트에 포함되지 않음.
- 사람이 참석하는 실제 교육 리허설은 수행하지 않음. 슬라이드의 시간은 권장 운영안.

PPTX에는 본문 60장, 부록 12장, 72개 발표자 노트와 부록 이동 링크가 있습니다.
PowerPoint의 사용자 지정 슬라이드 쇼에는 60분 핵심 15장 및 세 회차가 등록되어 있습니다.
