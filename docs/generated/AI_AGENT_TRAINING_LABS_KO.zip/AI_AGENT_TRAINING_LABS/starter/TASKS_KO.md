# 시작 과제 · 정답을 보기 전에

## 실습 1 · State와 Node 계약 (30분)

입력: `fixtures/normal.json`. `contracts.csv`의 빈 칸을 채우고 5~7개 Node의 Graph를 그리세요.
0~8분 입력·결과 분류, 8~20분 작성·읽기 Node, 20~30분 병렬 충돌·저장 검토.
접수, Metrics, Runbook, Gate, 승인, 실행의 책임을 표시하세요. 접수를 함수로 만들거나 초기 입력 경계로 둘 수 있습니다.
`metrics`와 `runbook`이 같은 키를 동시에 갱신하지 않게 하세요. 실패·빈 결과·미실행을 구분하세요.
모델 Client나 DB connection을 State에 넣지 마세요.

## 실습 2 · Evidence와 승인 (30분)

`policy.py`를 구현하세요. 아래의 작은 계약과 기대 결과를 사용합니다.

```python
# 기대 계약: {status, verified_sources, rejected_sources}
evidence_gate({'metric-7', 'runbook-12'}, {'runbook-12'}, True)
# status='awaiting_approval', verified_sources=['runbook-12'], rejected_sources=[]
evidence_gate({'metric-7'}, {'invented-9'}, True)
# status='blocked', verified_sources=[], rejected_sources=['invented-9']
evidence_gate(set(), set(), False)
# status='blocked'; 빈 근거는 승인하지 않음
```

단순 교집합은 의미적 타당성을 판정하지 않는다는 제한을 설명하세요.
이후 `solution/`의 전체 Graph로 정상 대기·거부·잘못된 Incident/Action·근거 없음의 결과를 확인하세요.
제출: 상태 결과와 호출 수. 차단·거부 경로에서는 `len(sim.calls) == 0`을 검증해야 합니다.

## 실습 3 · 실패 주입과 복구 (30분)

`solution/test_workflow.py`를 복사해 개인 실습 파일을 만들고 다음 두 테스트를 직접 작성하세요.
1. `tool_timeout`: reason이 transient_timeout이고 실행 0회.
2. `invalid_output`: reason이 invalid_output이고 실행 0회.
정답에는 두 시나리오를 매개변수화한 테스트가 있으므로 작성 후 비교하세요.

설계 메모: 외부 Email 발송은 성공했지만 응답이 사라졌다. 실패로 단정하지 않고 실행 키로 결과를 조회·조정하는 흐름을 적으세요.
실제 Email이나 운영 DB를 변경하지 않습니다. 실습 Simulator는 외부 시스템을 호출하지 않습니다.

## 정답의 한계

`solution/`은 교육용 정답입니다. 인증·인가, 완전한 의미 검증, Provider 멱등성, 외부 실행 원장, 운영 동시성은 구현하지 않았습니다.
정답의 성공을 Day 25 원본 또는 실제 운영 시스템의 검증 결과로 확대하지 마세요.
