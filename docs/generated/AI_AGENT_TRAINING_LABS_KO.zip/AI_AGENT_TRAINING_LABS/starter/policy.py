"""연습용 작은 계약. 실행 가능한 정답은 solution/workflow.py에 있습니다."""
def evidence_gate(observed: set[str], claimed: set[str], required_ok: bool) -> dict:
    # TODO: verified/rejected 목록을 계산하고 필수 근거가 없으면 차단하세요.
    raise NotImplementedError("실습 2: 출처 대조와 상태를 구현하세요")

def approval_matches(plan: dict, approval: dict) -> bool:
    # TODO: incident_id, action_id, service, plan_version의 존재와 일치를 검사하세요.
    raise NotImplementedError("실습 2: 승인 대상을 결합하세요")
