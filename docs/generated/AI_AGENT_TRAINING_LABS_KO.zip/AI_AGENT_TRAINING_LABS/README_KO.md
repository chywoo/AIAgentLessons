# AI Agent 내부 교육 · 실습 패키지

이 패키지는 PPTX의 실습 1~3을 위한 **새 교육용 구현**입니다. 원본 Day 25 전체 코드가 아닙니다.
합성 입력과 FakeAgent·Simulator를 사용합니다. 의존성 설치 후 실습 실행에는 네트워크·GPU·모델 API key가 필요하지 않습니다.
실제 Email·운영 DB·사용자의 로컬 모델 서버에 연결하지 않습니다.

## 구성

- `starter/`: State 표, 구현할 작은 정책 계약, 과제 설명.
- `solution/`: LangGraph·Pydantic·SQLite를 사용하는 실행 가능한 정답.
- `fixtures/`: 정상·허위 출처·Runbook 없음 등 입력과 기대 결과. CLI는 `--fixture` 이름을 받아 같은 합성 데이터를 생성합니다.
- `requirements.in`: 직접 의존성의 고정 버전.
- `requirements.txt`: 전이 의존성까지 고정하고 다운로드 해시를 포함한 파일.
- `.env.example`: 비밀정보 없음. 기본 모드에 환경변수가 필요 없음을 안내.

## 설치 · Python 3.12

패키지 루트에서 실행합니다. 설치에는 PyPI 접근이 필요합니다. 이후 실행은 외부 서비스가 필요 없습니다.

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install --require-hashes -r requirements.txt
cd solution
python -m pytest -q test_workflow.py
```

Windows PowerShell에서는 `py -3.12 -m venv .venv`로 만든 뒤 `.venv\Scripts\Activate.ps1`을 사용합니다.
제작 시 검증 플랫폼은 Linux x86_64 / Python 3.12.14이며 Windows 실행을 직접 검증한 것은 아닙니다.

## 시연 · 중단과 다른 프로세스에서 재개

`solution/`에서 실행합니다.

```bash
python demo.py start --thread demo-42
python demo.py status --thread demo-42
python demo.py resume --thread demo-42 --decision reject
```

기대: start는 awaiting_approval, pending_nodes에 approval, Simulator 호출 0회.
마지막 명령은 별도 프로세스로 SQLite를 열어 같은 thread를 재개합니다. rejected와 호출 0회를 확인합니다.
반복 시 새 thread 이름을 사용하세요. 이미 시작한 thread의 덮어쓰기는 CLI가 거절합니다.

승인 예시:

```bash
python demo.py start --thread approve-42
python demo.py resume --thread approve-42 --decision approve
```

기대: simulated와 현재 프로세스의 Simulator 호출 1회. 이 계수는 운영 실행 원장이 아닙니다.

실패 예시:

```bash
python demo.py start --thread bad-42 --fixture invented_source
python demo.py start --thread empty-42 --fixture no_runbook
python demo.py start --thread timeout-42 --fixture tool_timeout
python demo.py start --thread schema-42 --fixture invalid_output
```

각 경로는 blocked와 호출 0회입니다. reason은 근거 부족 / transient_timeout / invalid_output으로 구분됩니다.

## 수업 진행

1. 실습 1: `starter/contracts.csv`와 Graph 스케치 제출 (30분).
2. 실습 2: `starter/policy.py` 작성 후 정답 Graph의 승인·거부·대상 오류 비교 (30분).
3. 실습 3: timeout·Schema 오류 테스트 2개 작성, 결과 불명확 복구 메모 제출 (30분).

학습자가 수정한 starter는 의도적으로 미완성이며 정답 테스트 13개에 포함되지 않습니다.
기본 검증 명령은 `solution/`에서 `python -m pytest -q test_workflow.py`입니다.

## 검증 기록 · 2026-10-20

고정된 requirements.txt를 새 가상환경에 해시 검증을 유지하여 설치했습니다.
정답 테스트 13개 통과. 승인 대기, 승인·거부, 허위·빈 근거, 네 종류 대상 불일치,
timeout·출력 오류, SQLite 닫기/다시 열기, 승인 필드 누락을 검사합니다.
start와 resume를 서로 다른 Python 프로세스로 실행하여 rejected / 호출 0회를 확인했습니다.
실제 모델·MCP Server·Qdrant·외부 변경은 통합 검증하지 않았습니다.

## 흔한 오류

- `ModuleNotFoundError`: 활성화한 Python과 pip가 같은 가상환경인지 확인하세요.
- `Thread already exists`: 새 --thread 또는 기존 thread의 status/resume를 사용하세요.
- `No paused execution`: DB 경로·thread가 같은지, 이미 종료된 실행인지 확인하세요.
- SQLite 접근 오류: 쓰기 가능한 디렉터리에서 실행하고, DB 파일을 여러 작업에서 공유하지 마세요.
- 학습용 CLI 승인에는 운영용 승인자 인증이 없습니다. 운영 승인 시스템으로 그대로 사용하지 마세요.

실제 모델 통합 모드는 이 패키지에 포함하지 않았습니다. 서버 접근·권한·모델의 Tool Calling 지원·SDK 호환성을 확보한 뒤 별도 통합 테스트로 수행합니다.
